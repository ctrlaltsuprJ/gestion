# Gestión DPI

Sistema web de gestión de equipos TI: inventario, usuarios, tickets, mantenimiento (con calendario), bitácoras, directorio IP, nodos/red, cursos y reportes.

**Stack:** PHP 8+, MySQL/MariaDB (PDO), Bootstrap 5, Chart.js, SweetAlert2.

## Estructura

```
/                     Páginas (una por módulo): index, equipos, usuarios, tickets, ...
├── includes/         Núcleo: auth, db, functions, header, footer y *_functions por módulo
├── exports/          Exportaciones PDF/Excel (export_*.php)
├── assets/           css/ js/ y librerías locales (bst/, sweetalert2, font/ — no versionadas)
└── _revisar/         Archivos sin referencias, pendientes de decidir
```

## Instalación

1. Copia el proyecto a `htdocs/gestion/` (XAMPP) o equivalente.
2. Crea la BD e importa el esquema (`schema.sql` / dump).
3. `cp includes/db.example.php includes/db.php` y edita credenciales.
4. Coloca las librerías en `assets/` (bootstrap, bootstrap-icons, sweetalert2).
5. Abre `http://localhost/gestion/`.

> `includes/db.php` está en `.gitignore`: nunca subas credenciales ni dumps con datos reales.
